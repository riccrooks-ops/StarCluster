==============================================================
15th Ultra Release (Official)  -- This is the April 2009 release.
==============================================================

There are now two zip files.  Unzip into the same directory.
NOTE:  There is a file attached to THIS E-mail also.

Remember to delete the previous Ultra file since you'd hate to open
the wrong one at the wrong time <G>.

NOTE:  When advising me that your not getting the Ultra file, use
your full name so that it is easier for me to check your subscription status.

================
New Developments
================
You will notice that Ultra came in many small PDFs this time.  This
appears to be the only way around the problem that was holding up
Ultra releases.  It may be possible in the future to have incremental
upgrades by just sending a couple of files.  We'll see about that later.

Using the new files
--Left clicking a link causes the old file to close and the new one to open
--Right clicking give you a choice to keep the old one open
--Pressing the back button will return you to a closed file if you
got there with a link.

Let me know of any other useful tips for using acrobat reader.

---- STARFIREONLINE.COM ----
StarfireOnline.com is able to handle Ultra campaigns now.  It is
still free and is far better than using paper.

There are parts that still need some work
-----
* Small Craft vs AP need looked at.  I'm strangely concerned that the
gunboats are too powerful.  Fighters seem ok though.
* Adding new technologies that start at SL 25+.
* Evaluate current optional technologies for inclusion into the main stream.
-------


New things -- 4-2009
WP generation of Top Secret WPs clarified
A number of things clarified and few actual changes.


=====
Remember, suggestions and comments are welcome.  If you think a link from a
certain rule to another rule would be helpful, speak up.  If a rule is
unclear, it is easy to change now.

NOTE:  This is being sent via a separate E-mail from the main file.
For questions and discussion about Starfire
<http://www.starfiredesign.com/forum/>http://www.starfiredesign.com/forum/

This E-mail is always sent in conjunction with a 2nd E-mail with the
attached ULTRA file. If you have not received the file within 12
hours of this E-mail, it is highly likely that your E-mail address is
incapable of handling a roughly 8.5 MB zip file.  Check with your
provider to see if that is the case.  Either asked them to increase
the size of your mailbox/maximum file size download, or find another
e-mail address that can handle that size.  Yahoo accounts work fine
and are free.

Congratulations and enjoy!!!
